Bootstrap Admin
===============
Donate link: http://aristeides.com/bootstrap-admin
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A clean, minimalistic administration theme inspired from Twitter's Bootstrap (http://twitter.github.com/bootstrap )

Description
===============

A clean, minimalistic administration theme implementing Twitter's Bootstrap.
You can get it on github here: http://aristeides.com/bootstrap-admin

This project was built for the http://magazi.org network of stores.
This plugin will continue to be improved.

So far these things have been done:

* General styling of the wordpress admin area
* Admin menu sub-menus as bootstrap popovers (they're actually very beautiful!)
* Bootstrap Icons for a lot of things
* Default WordPress forms theming
* Buttons theming
* Postboxes theming
* Includes WPMUdev Pro-Sites optimizations
* Includes WPMUdev MarketPress optimizations
* Even more, and a lot more on the way!

If you like it and use it on your projects, please consider donating @ http://aristeides.com 

Installation
===============

Just copy to your plugins folder and activate (or Network activate) it.