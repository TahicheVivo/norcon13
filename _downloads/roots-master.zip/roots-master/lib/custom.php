<?php
/**
 * Custom functions
 */
